import { Greeter } from './greeter';

const g = new Greeter('Juri');
g.greet();
